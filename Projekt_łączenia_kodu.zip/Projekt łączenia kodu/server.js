const express = require("express");
const path = require("path");
const fs = require("fs");
const https = require("https");

const app = express();
const PORT = 3000;
let qrVerified = false; 

// ------------------------------------------------------
// 1. Wczytanie allowed-domains.json z folderu /public
// ------------------------------------------------------

// Poprawiona ścieżka – teraz wskazuje prawidłowe miejsce:
const domainsFilePath = path.join(__dirname, "data", "allowed-domains.json");

// Lista domen wczytana do pamięci
let allowedDomains = new Set();

function loadAllowedDomains() {
    try {
        const raw = fs.readFileSync(domainsFilePath, "utf8");
        const json = JSON.parse(raw);

        if (Array.isArray(json)) {
            json.forEach(d => {
                if (typeof d === "string") allowedDomains.add(d.trim().toLowerCase());
            });
        } else if (Array.isArray(json.domains)) {
            json.domains.forEach(d => {
                if (typeof d === "string") allowedDomains.add(d.trim().toLowerCase());
            });
        } else {
            console.warn("⚠ allowed-domains.json ma nieoczekiwany format.");
        }

        console.log(`✅ Wczytano ${allowedDomains.size} domen z allowed-domains.json`);
    } catch (err) {
        console.warn("❌ Nie udało się wczytać allowed-domains.json:", err.message);
        allowedDomains = new Set();
    }
}

loadAllowedDomains();

// Serwowanie plików statycznych
app.use(express.static(path.join(__dirname, "public")));
app.use((req, res, next) => {
    console.log(`📥 ${new Date().toISOString()} - ${req.method} ${req.url}`);
    console.log(`   From: ${req.ip}`);
    next();
});

// ------------------------------------------------------
// 2. Endpoint: /api/verify-domain
// ------------------------------------------------------
app.get("/api/verify-domain", (req, res) => {
    const site = req.query.site;

    if (!site) {
        return res.json({
            error: "Brak parametru 'site'",
            verified: false,
            inGovList: false,
            httpsUsed: false,
            sslOk: false
        });
    }

    let url;
    try {
        url = new URL(site);
    } catch (e) {
        return res.json({
            error: "Nieprawidłowy adres URL",
            verified: false,
            inGovList: false,
            httpsUsed: false,
            sslOk: false
        });
    }

    const hostname = url.hostname.toLowerCase();
    const hostNoWww = hostname.replace(/^www\./, "");
    const httpsUsed = url.protocol.toLowerCase() === "https:";

    // Sprawdzenie w allowed-domains.json
    let inGovList = false;

    if (allowedDomains.size > 0) {
        inGovList =
            allowedDomains.has(hostname) ||
            allowedDomains.has(hostNoWww);
    } else {
        console.warn("⚠ Lista domen nie została wczytana — fallback *.gov.pl");
        //inGovList = hostNoWww.endsWith(".gov.pl");
        inGovList = false;
    }

    // Jeśli brak HTTPS → nie sprawdzamy certyfikatu
    if (!httpsUsed) {
        return res.json({
            verified: false,
            inGovList,
            httpsUsed,
            sslOk: false
        });
    }

    // ------------------------------------------------------
    // 3. Sprawdzanie certyfikatu SSL
    // ------------------------------------------------------
    const requestOptions = {
        method: "GET",
        timeout: 4000
    };

    const request = https.request(url, requestOptions, (response) => {
        const sslOk = response.socket ? response.socket.authorized !== false : true;
        const verified = inGovList && httpsUsed && sslOk;

        res.json({
            verified,
            inGovList,
            httpsUsed,
            sslOk
        });
    });

    request.on("error", (err) => {
        console.warn("❌ Błąd przy sprawdzaniu SSL:", err.message);
        res.json({
            verified: false,
            inGovList,
            httpsUsed,
            sslOk: false
        });
    });

    request.end();
});

// Domyślnie serwujemy index.html
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "public", "index.html"));
});
app.post("/api/qr-scanned", express.json(), (req, res) => {
    const { url } = req.body;
    const hostname = new URL(url).hostname.toLowerCase();
    const hostNoWww = hostname.replace(/^www\./, "");
    const httpsUsed = url.startsWith("https:");

    const inGovList = allowedDomains.has(hostname) || allowedDomains.has(hostNoWww);

    qrVerified = inGovList && httpsUsed; // Update global status

    console.log("📱 QR scanned - verified:", qrVerified);

    res.json({ success: true, verified: qrVerified });
});

app.get("/api/qr-scanned-status", (req, res) => {
    res.json({ verified: qrVerified });
});

app.listen(PORT, () => {
    console.log(`🚀 Serwer działa na http://0.0.0.0:${PORT}`);
});

