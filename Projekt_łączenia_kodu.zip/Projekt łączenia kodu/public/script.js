let isModalOpen = false;
let timerInterval = null;
let currentTimer = 60;
let qrCodeObj = null;

let sessionStatus = 'none';
let sessionEndTime = null;

// Domain verification
let allowedDomains = [];



// Load allowed domains from JSON file
fetch('https://raw.githubusercontent.com/gov-pl/allowed-domains/main/allowed-domains.json')
    .then(res => res.json())
    .then(data => {
        allowedDomains = data;
        console.log('Loaded', allowedDomains.length, 'allowed GOV.PL domains');
    })
    .catch(err => {
        console.error('Error loading allowed domains:', err);
        // Fallback: try local file
        fetch('../data/allowed-domains.json')
            .then(res => res.json())
            .then(data => {
                allowedDomains = data;
                console.log('Loaded', allowedDomains.length, 'allowed GOV.PL domains from local file');
            })
            .catch(err2 => console.error('Error loading local allowed domains:', err2));
    });

// Verify current site domain

let qrPollingInterval = null;

function onQrScanned() {
    const payload = generateUniquePayload(); // same payload used in QR
    const deviceInfo = navigator.userAgent;

    fetch("/api/qr-scanned", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: payload, timestamp: Date.now(), deviceInfo })
    })
    .then(res => res.json())
    .then(data => {
        console.log("QR scan registered:", data);

        // Update CSS / classes based on verification
        const viewSuccess = document.getElementById("view-success");
        const viewError = document.getElementById("view-error");
        const viewScanning = document.getElementById("view-scanning");

        if (!viewSuccess || !viewError || !viewScanning) return;

        if (data.verified) {
            viewSuccess.classList.add("active");
            viewError.classList.remove("active");
            viewScanning.classList.remove("active");

            stopQrPolling(); // ✅ stop polling once verified
        } else {
            viewError.classList.add("active");
            viewSuccess.classList.remove("active");
            viewScanning.classList.remove("active");
        }
    })
    .catch(err => {
        console.error("Error during verification:", err);
        const viewError = document.getElementById("view-error");
        const viewSuccess = document.getElementById("view-success");
        const viewScanning = document.getElementById("view-scanning");
        if (viewError && viewSuccess && viewScanning) {
            viewError.classList.add("active");
            viewSuccess.classList.remove("active");
            viewScanning.classList.remove("active");
        }
    });
}

function startQrPolling() {
    if (qrPollingInterval) return;

    qrPollingInterval = setInterval(() => {
        // Check status instead of sending verification
        fetch("/api/qr-scanned-status")
            .then(res => res.json())
            .then(data => {
                const viewSuccess = document.getElementById("view-success");
                const viewError = document.getElementById("view-error");
                const viewScanning = document.getElementById("view-scanning");

                if (!viewSuccess || !viewError || !viewScanning) return;

                if (data.verified) {
                    // ✅ Success case
                    viewSuccess.classList.add("active");
                    viewError.classList.remove("active");
                    viewScanning.classList.remove("active");
                    stopQrPolling();
                } else if (data.verified === false) {
                    // ❌ Failed verification case
                    viewError.classList.add("active");
                    viewSuccess.classList.remove("active");
                    viewScanning.classList.remove("active");
                    stopQrPolling();
                }
                // If data.verified is undefined/null, keep scanning state
            })
            .catch(err => {
                console.error("Status check error:", err);
                const viewError = document.getElementById("view-error");
                const viewSuccess = document.getElementById("view-success");
                const viewScanning = document.getElementById("view-scanning");
                
                if (viewError && viewSuccess && viewScanning) {
                    viewError.classList.add("active");
                    viewSuccess.classList.remove("active");
                    viewScanning.classList.remove("active");
                }
                stopQrPolling();
            });
    }, 3000);
}

function stopQrPolling() {
    if (qrPollingInterval) {
        clearInterval(qrPollingInterval);
        qrPollingInterval = null;
    }
}

function toggleVerificationModal() {
    const modal = document.getElementById('gov-verify-modal');
    isModalOpen = !isModalOpen;

    if (isModalOpen) {
        modal.classList.add('active');

        // Show scanning view immediately
        const viewScanning = document.getElementById("view-scanning");
        const viewSuccess = document.getElementById("view-success");
        const viewError = document.getElementById("view-error");

        if (viewScanning && viewSuccess && viewError) {
            viewScanning.classList.add("active");
            viewSuccess.classList.remove("active");
            viewError.classList.remove("active");
        }

        startQrPolling(); // start polling every 3 seconds

        if (sessionStatus === 'active') {
            updateTimerDisplay();
        } else if (sessionStatus === 'none' || sessionStatus === 'expired') {
            initSession();
        }
    } else {
        modal.classList.remove('active');
        stopQrPolling(); // stop polling when modal closes
    }
}



function showState(stateName) {
    document.querySelectorAll('.view-section').forEach(el => el.classList.remove('active'));

    if (stateName === 'success') {
        document.getElementById('view-success').classList.add('active');
        stopTimer(true);
    } else if (stateName === 'error') {
        document.getElementById('view-error').classList.add('active');
        stopTimer(true);
    } else {
        document.getElementById('view-scanning').classList.add('active');
    }
}

function checkAndRestoreSession() {
    const savedEndTime = sessionStorage.getItem('gov_verify_end_time');
    const savedPayload = sessionStorage.getItem('gov_verify_payload');
    const savedCode = sessionStorage.getItem('gov_verify_code');

    if (savedEndTime && savedPayload) {
        const remaining = Math.ceil((parseInt(savedEndTime) - Date.now()) / 1000);

        if (remaining > 0) {
            sessionEndTime = parseInt(savedEndTime);
            currentTimer = remaining;
            sessionStatus = 'active';
            renderQRCode(savedPayload);

            if (savedCode) {
                const textCodeEl = document.getElementById('text-code-display');
                const toggleBtn = document.getElementById('btn-toggle-text-code');
                if (textCodeEl) {
                    textCodeEl.innerText = savedCode;
                    textCodeEl.style.display = 'block';
                }
                if (toggleBtn) {
                    toggleBtn.innerText = 'Schowaj kod weryfikacyjny';
                }
            }

            startTimerLogic(false);
        } else {
            sessionStatus = 'expired';
            expireQRCode();
        }
    }
}

function initSession() {
    localStorage.removeItem('gov_verify_end_time');
    localStorage.removeItem('gov_verify_payload');

    const payload = generateUniquePayload();
    sessionStorage.setItem('gov_verify_payload', payload);
    renderQRCode(payload);

    const codeBuffer = new Uint32Array(1);
    window.crypto.getRandomValues(codeBuffer);
    const randomCode = (codeBuffer[0] % 900000) + 100000;

    sessionStorage.setItem('gov_verify_code', randomCode);

    const textCodeEl = document.getElementById('text-code-display');
    const toggleBtn = document.getElementById('btn-toggle-text-code');

    if (textCodeEl) {
        textCodeEl.innerText = randomCode;
        textCodeEl.style.display = 'none';
        textCodeEl.style.color = "";
        textCodeEl.style.fontSize = "24px";
        textCodeEl.style.letterSpacing = "4px";
    }
    if (toggleBtn) {
        toggleBtn.innerText = 'Pokaż kod weryfikacyjny';
    }

    startTimerLogic(true);
    sessionStatus = 'active';
}

function renderQRCode(payload) {
    const qrContainer = document.getElementById('qrcode');
    if (!qrContainer) return;
    qrContainer.innerHTML = '';

    qrCodeObj = new QRCode(qrContainer, {
        text: payload,
        width: 120,
        height: 120,
        colorDark: "#003764",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.H
    });
}

function generateUniquePayload() {
    const currentUrl = window.location.href;
    return currentUrl;
}

function startTimerLogic(reset = false) {
    if (timerInterval) clearInterval(timerInterval);

    if (reset) {
        currentTimer = 60;
        sessionEndTime = Date.now() + (60 * 1000);
        sessionStorage.setItem('gov_verify_end_time', sessionEndTime);
    }

    updateTimerDisplay();

    const timerTextEl = document.querySelector('.timer-text');
    if (timerTextEl) {
        timerTextEl.innerHTML = 'Pozostały czas: <span id="timer-count">60</span>s';
        timerTextEl.style.display = 'block';
    }

    const textCodeContainer = document.getElementById('text-code-container');
    if (textCodeContainer) {
        textCodeContainer.style.display = 'flex';
    }

    timerInterval = setInterval(() => {
        const now = Date.now();
        const delta = Math.ceil((sessionEndTime - now) / 1000);
        currentTimer = delta > 0 ? delta : 0;

        if (currentTimer <= 0) {
            expireQRCode();
        } else {
            updateTimerDisplay();
        }
    }, 1000);
}


function stopTimer(clearStorage = false) {
    if (timerInterval) {
        clearInterval(timerInterval);
        timerInterval = null;
    }
    if (clearStorage) {
        sessionStorage.removeItem('gov_verify_end_time');
        sessionStorage.removeItem('gov_verify_payload');
        sessionStorage.removeItem('gov_verify_code');
        sessionStatus = 'none';
        sessionEndTime = null;
    }
}

function updateTimerDisplay() {
    const timerEl = document.getElementById('timer-count');
    if (timerEl) timerEl.innerText = currentTimer;

    const timerText = document.querySelector('.timer-text');
    const qrContainer = document.querySelector('.qr-scanner-container');

    if (timerText && qrContainer) {
        if (currentTimer <= 10 && currentTimer > 0) {
            timerText.classList.add('urgent-text');
            qrContainer.classList.add('urgent-pulse');
        } else {
            timerText.classList.remove('urgent-text');
            qrContainer.classList.remove('urgent-pulse');
        }
    }
}

function expireQRCode() {
    if (timerInterval) clearInterval(timerInterval);
    timerInterval = null;
    sessionStatus = 'expired';

    sessionStorage.removeItem('gov_verify_end_time');
    sessionStorage.removeItem('gov_verify_code');

    const qrContainer = document.getElementById('qrcode');
    if (qrContainer) {
        qrContainer.innerHTML = '';
    }
    qrCodeObj = null;

    const textCodeContainer = document.getElementById('text-code-container');
    if (textCodeContainer) {
        textCodeContainer.style.display = 'none';
    }

    const timerTextEl = document.querySelector('.timer-text');
    if (timerTextEl) {
        timerTextEl.style.display = 'none';
        timerTextEl.classList.remove('urgent-text');
    }

    const qrScC = document.querySelector('.qr-scanner-container');
    if (qrScC) qrScC.classList.remove('urgent-pulse');
}

function regenerateCode() {
    initSession();
}

function toggleTextCode() {
    const codeDisplay = document.getElementById('text-code-display');
    const button = document.getElementById('btn-toggle-text-code');

    if (codeDisplay.style.display === 'none') {
        codeDisplay.style.display = 'block';
        button.innerText = 'Schowaj kod weryfikacyjny';
    } else {
        codeDisplay.style.display = 'none';
        button.innerText = 'Pokaż kod weryfikacyjny';
    }
}

function removeWidget(event) {
    event.stopPropagation();
    const widget = document.getElementById('gov-verify-cta');
    if (widget) {
        widget.style.display = 'none';

        const modal = document.getElementById('gov-verify-modal');
        if (modal.classList.contains('active')) {
            toggleVerificationModal();
        }
    }
}

document.getElementById('gov-verify-modal').addEventListener('click', function (e) {
    if (e.target === this) {
        toggleVerificationModal();
    }
});

document.addEventListener('DOMContentLoaded', () => {
    checkAndRestoreSession();
});
