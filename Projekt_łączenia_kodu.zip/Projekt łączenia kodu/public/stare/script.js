// --------- WERYFIKACJA PRZEZ BACKEND /api/verify-domain ----------
function verifyCurrentSite() {
    const params = new URLSearchParams(window.location.search);
    const siteParam = params.get('site') || window.location.origin;

    const verifyUrlEl    = document.getElementById('verifyUrl');
    const verifyResultEl = document.getElementById('verifyResult');

    verifyUrlEl.textContent = siteParam;
    verifyResultEl.className = 'verify-result loading';
    verifyResultEl.textContent = 'Sprawdzanie autentyczności...';

    fetch('/api/verify-domain?site=' + encodeURIComponent(siteParam))
        .then(res => res.json())
        .then(data => {
            console.log('Wynik weryfikacji domeny:', data);

            if (data.error) {
                verifyResultEl.className = 'verify-result unsafe';
                verifyResultEl.textContent = 'Błąd weryfikacji: ' + data.error;
                return;
            }

            if (data.verified) {
                verifyResultEl.className = 'verify-result safe';
                verifyResultEl.textContent =
                    '✅ Strona zweryfikowana: domena w rejestrze gov.pl, poprawne połączenie HTTPS.';
            } else {
                let reasons = [];

                if (!data.inGovList) {
                    reasons.push('domena nie jest w oficjalnej liście gov.pl');
                }

                if (!data.httpsUsed) {
                    reasons.push('adres nie używa HTTPS');
                }

                // jeśli jest HTTPS, ale certyfikat SSL jest błędny
                if (data.httpsUsed && data.sslOk === false) {
                    reasons.push('problem z certyfikatem SSL');
                }

                // jeśli nadal brak powodów → bezpieczne fallback
                if (reasons.length === 0) {
                    reasons.push('strona nie spełnia wymogów bezpieczeństwa');
                }

                verifyResultEl.className = 'verify-result unsafe';
                verifyResultEl.textContent =
                    '⚠ Strona NIE została zweryfikowana: ' + reasons.join(', ') + '.';
            }
        })
        .catch(err => {
            console.error(err);
            verifyResultEl.className = 'verify-result unsafe';
            verifyResultEl.textContent = 'Błąd komunikacji z serwerem weryfikacji.';
        });
}

// --------- FUNKCJA DO ROZMYCIA / ODSŁANIANIA TEKSTU ----------
function toggleBlur() {
    const el = document.getElementById("statusText");
    el.classList.toggle("blurred");
    el.classList.toggle("visible");
}

// --------- LOGIKA MODALA I QR ----------
let qrInstance = null;
let timeLeft = 60;
let timerInterval = null;

function resetQrVisual() {
    const qrContainer = document.getElementById('qrCode');
    const timerEl     = document.getElementById('timer');
    const statusText  = document.getElementById('statusText');

    qrContainer.classList.remove('pulse', 'fade-out', 'warning');
    qrContainer.style.opacity = '1';

    if (timerEl) {
        timerEl.classList.remove('expired', 'warning');
    }

    // przy każdym nowym kodzie – z powrotem zamazany, z napisem "Kliknij..."
    statusText.classList.add('blurred');
    statusText.classList.remove('visible');
}

function generateQRCode(randomCode) {
    const qrContainer = document.getElementById('qrCode');
    const statusText  = document.getElementById('statusText');
    const statusInner = statusText.querySelector('.status-inner');
    const timerEl     = document.getElementById('timer');

    qrContainer.innerHTML = '';
    resetQrVisual();

    qrInstance = new QRCode(qrContainer, {
        text: randomCode,
        width: 180,
        height: 180,
        colorDark: "#000000",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.H
    });

    if (statusInner) {
        statusInner.textContent = 'Aktualny kod: ' + randomCode;
    }

    if (timerEl) {
        timerEl.textContent = `Pozostały czas: ${timeLeft}s`;
    }

    startTimer();
}

function generateNewCode() {
    if (timerInterval) clearInterval(timerInterval);
    const params = new URLSearchParams(window.location.search);
    const currentSite = params.get('site') || window.location.origin;
    const code = currentSite;
    generateQRCode(code);
}

function startTimer() {
    const timerEl     = document.getElementById('timer');
    const qrContainer = document.getElementById('qrCode');

    if (timerInterval) clearInterval(timerInterval);

    updateTimerDisplay();

    timerInterval = setInterval(() => {
        timeLeft--;
        updateTimerDisplay();

        // OSTATNIE 5 SEKUND – czerwony timer + pulsowanie + czerwona poświata
        if (timeLeft <= 5 && timeLeft > 0) {
            qrContainer.classList.add('pulse', 'warning');
            timerEl.classList.add('warning');
        } else {
            qrContainer.classList.remove('pulse', 'warning');
            timerEl.classList.remove('warning');
        }

        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            expireCode();
        }
    }, 1000);
}

function updateTimerDisplay() {
    const timerEl = document.getElementById('timer');
    if (!timerEl) return;

    if (timeLeft > 0) {
        timerEl.textContent = `Pozostały czas: ${timeLeft}s`;
    } else {
        timerEl.textContent = '';
    }

    timerEl.classList.toggle('expired', timeLeft <= 0);
}

function expireCode() {
    const qrContainer = document.getElementById('qrCode');
    const statusText  = document.getElementById('statusText');
    const statusInner = statusText.querySelector('.status-inner');
    const timerEl     = document.getElementById('timer');

    // po wygaśnięciu – zero pulsowania i ostrzegania
    qrContainer.classList.remove('pulse', 'warning');

    if (timerEl) {
        timerEl.classList.remove('warning');
        timerEl.textContent = '';
        timerEl.classList.add('expired');
    }

    // wyraźny komunikat bez blur / bez napisu "Kliknij..."
    if (statusInner) {
        statusInner.textContent = 'Kod wygasł — wygeneruj nowy.';
    }
    statusText.classList.remove('blurred');
    statusText.classList.remove('visible');

    qrContainer.classList.add('fade-out');

    setTimeout(() => {
        if (qrInstance) qrInstance.clear();
        qrContainer.innerHTML = '<div style="color:#666;font-size:14px;">Kod wygasł</div>';
    }, 300);
}

// --------- EVENTY PO ZAŁADOWANIU DOMU ----------
document.addEventListener('DOMContentLoaded', () => {
    const modalOverlay   = document.getElementById('modalOverlay');
    const qrOpenBtn      = document.getElementById('qrOpenBtn');
    const closeModalBtn  = document.getElementById('closeModalBtn');
    const refreshCodeBtn = document.getElementById('refreshCodeBtn');

    function openModal() {
        modalOverlay.classList.add('active');
        verifyCurrentSite();
        generateNewCode();
    }

    function closeModal() {
        modalOverlay.classList.remove('active');
        if (timerInterval) clearInterval(timerInterval);
    }

    qrOpenBtn.addEventListener('click', openModal);
    closeModalBtn.addEventListener('click', closeModal);

    modalOverlay.addEventListener('click', (event) => {
        if (event.target === modalOverlay) {
            closeModal();
        }
    });

    refreshCodeBtn.addEventListener('click', generateNewCode);
});
